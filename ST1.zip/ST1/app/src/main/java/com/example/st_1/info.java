package com.example.st_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        final EditText name = (EditText) findViewById(R.id.namepr);
        final   EditText email = (EditText) findViewById(R.id.email);
        final  EditText number = (EditText) findViewById(R.id.phone);
        final EditText blood = (EditText) findViewById(R.id.type);


        Button Submit = (Button) findViewById(R.id.button2);





        TextView alert = findViewById(R.id.button2);
        alert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(info.this,MainActivity.class);
                intent.putExtra("name",name.getText().toString());
                intent.putExtra("email",email.getText().toString());
                 intent.putExtra("number",number.getText().toString());
                intent.putExtra("blood",blood.getText().toString());
                startActivity(intent);

            }
        });

    }



}